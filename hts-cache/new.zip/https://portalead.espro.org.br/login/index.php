<!DOCTYPE html>

<html  dir="ltr" lang="en" xml:lang="en">
<head>
    <title>Log in to the site |  </title>
<link rel="shortcut icon" href="//portalead.espro.org.br/pluginfile.php/1/theme_snap/favicon/1723176132/favicon.png"/>
<meta name="apple-itunes-app" content="app-id=1553337282, app-argument=https://portalead.espro.org.br/login/index.php"/><link rel="manifest" href="https://portalead.espro.org.br/admin/tool/mobile/mobile.webmanifest.php" /><meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="moodle, Log in to the site |  " />
<link rel="stylesheet" type="text/css" href="https://portalead.espro.org.br/theme/yui_combo.php?3.18.1/cssgrids/cssgrids-min.css" /><link rel="stylesheet" type="text/css" href="https://portalead.espro.org.br/theme/yui_combo.php?rollup/3.18.1/yui-moodlesimple-min.css" /><script id="firstthemesheet" type="text/css">/** Required in order to fix style inclusion problems in IE with YUI **/</script><link rel="stylesheet" type="text/css" href="https://portalead.espro.org.br/theme/styles.php/snap/1723176132_1723176725/all" />
<script>
//<![CDATA[
var M = {}; M.yui = {};
M.pageloadstarttime = new Date();
M.cfg = {"wwwroot":"https:\/\/portalead.espro.org.br","homeurl":{},"sesskey":"0psCOoKqLc","sessiontimeout":"14400","sessiontimeoutwarning":1200,"themerev":"1723176132","slasharguments":1,"theme":"snap","iconsystemmodule":"core\/icon_system_fontawesome","jsrev":"1723176132","admin":"admin","svgicons":true,"usertimezone":"America\/Sao_Paulo","language":"en","courseId":1,"courseContextId":2,"contextid":1,"contextInstanceId":0,"langrev":1723176132,"templaterev":"1723176132"};var yui1ConfigFn = function(me) {if(/-skin|reset|fonts|grids|base/.test(me.name)){me.type='css';me.path=me.path.replace(/\.js/,'.css');me.path=me.path.replace(/\/yui2-skin/,'/assets/skins/sam/yui2-skin')}};
var yui2ConfigFn = function(me) {var parts=me.name.replace(/^moodle-/,'').split('-'),component=parts.shift(),module=parts[0],min='-min';if(/-(skin|core)$/.test(me.name)){parts.pop();me.type='css';min=''}
if(module){var filename=parts.join('-');me.path=component+'/'+module+'/'+filename+min+'.'+me.type}else{me.path=component+'/'+component+'.'+me.type}};
YUI_config = {"debug":false,"base":"https:\/\/portalead.espro.org.br\/lib\/yuilib\/3.18.1\/","comboBase":"https:\/\/portalead.espro.org.br\/theme\/yui_combo.php?","combine":true,"filter":null,"insertBefore":"firstthemesheet","groups":{"yui2":{"base":"https:\/\/portalead.espro.org.br\/lib\/yuilib\/2in3\/2.9.0\/build\/","comboBase":"https:\/\/portalead.espro.org.br\/theme\/yui_combo.php?","combine":true,"ext":false,"root":"2in3\/2.9.0\/build\/","patterns":{"yui2-":{"group":"yui2","configFn":yui1ConfigFn}}},"moodle":{"name":"moodle","base":"https:\/\/portalead.espro.org.br\/theme\/yui_combo.php?m\/1723176132\/","combine":true,"comboBase":"https:\/\/portalead.espro.org.br\/theme\/yui_combo.php?","ext":false,"root":"m\/1723176132\/","patterns":{"moodle-":{"group":"moodle","configFn":yui2ConfigFn}},"filter":null,"modules":{"moodle-core-event":{"requires":["event-custom"]},"moodle-core-notification":{"requires":["moodle-core-notification-dialogue","moodle-core-notification-alert","moodle-core-notification-confirm","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-core-notification-dialogue":{"requires":["base","node","panel","escape","event-key","dd-plugin","moodle-core-widget-focusafterclose","moodle-core-lockscroll"]},"moodle-core-notification-alert":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-confirm":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-exception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-notification-ajaxexception":{"requires":["moodle-core-notification-dialogue"]},"moodle-core-maintenancemodetimer":{"requires":["base","node"]},"moodle-core-actionmenu":{"requires":["base","event","node-event-simulate"]},"moodle-core-formchangechecker":{"requires":["base","event-focus","moodle-core-event"]},"moodle-core-dragdrop":{"requires":["base","node","io","dom","dd","event-key","event-focus","moodle-core-notification"]},"moodle-core-handlebars":{"condition":{"trigger":"handlebars","when":"after"}},"moodle-core-chooserdialogue":{"requires":["base","panel","moodle-core-notification"]},"moodle-core-blocks":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification"]},"moodle-core-lockscroll":{"requires":["plugin","base-build"]},"moodle-core_availability-form":{"requires":["base","node","event","event-delegate","panel","moodle-core-notification-dialogue","json"]},"moodle-backup-backupselectall":{"requires":["node","event","node-event-simulate","anim"]},"moodle-course-management":{"requires":["base","node","io-base","moodle-core-notification-exception","json-parse","dd-constrain","dd-proxy","dd-drop","dd-delegate","node-event-delegate"]},"moodle-course-util":{"requires":["node"],"use":["moodle-course-util-base"],"submodules":{"moodle-course-util-base":{},"moodle-course-util-section":{"requires":["node","moodle-course-util-base"]},"moodle-course-util-cm":{"requires":["node","moodle-course-util-base"]}}},"moodle-course-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-course-coursebase","moodle-course-util"]},"moodle-course-categoryexpander":{"requires":["node","event-key"]},"moodle-form-dateselector":{"requires":["base","node","overlay","calendar"]},"moodle-form-shortforms":{"requires":["node","base","selector-css3","moodle-core-event"]},"moodle-question-searchform":{"requires":["base","node"]},"moodle-question-chooser":{"requires":["moodle-core-chooserdialogue"]},"moodle-question-preview":{"requires":["base","dom","event-delegate","event-key","core_question_engine"]},"moodle-core_outcome-simpleio":{"requires":["base","io-base","json-parse","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-core_outcome-mapoutcome":{"requires":["widget","handlebars","json-parse","json-stringify","moodle-core_outcome-models","moodle-core_outcome-outcomepanel","moodle-core-notification-exception"]},"moodle-core_outcome-outcomepanel":{"requires":["base","handlebars","moodle-core_outcome-models","moodle-core_outcome-scrollpanel","moodle-core_outcome-ariacontrol","moodle-core_outcome-ariacontrolled","moodle-core-notification-dialogue","moodle-core-notification-alert","moodle-core_outcome-simpleio"]},"moodle-core_outcome-scrollpanel":{"requires":["plugin","widget","panel"]},"moodle-core_outcome-models":{"requires":["base","model","model-list","moodle-core_outcome-simpleio","json-stringify"]},"moodle-core_outcome-editoutcome":{"requires":["widget","event-valuechange","handlebars","json-parse","json-stringify","moodle-core_outcome-models","moodle-core-notification-dialogue","moodle-core-notification-exception"]},"moodle-core_outcome-mapoutcomeset":{"requires":["widget","model","model-list","handlebars","json-parse","json-stringify","moodle-core_outcome-models","moodle-core-notification-dialogue","moodle-core-notification-exception","moodle-core-notification-alert","moodle-core_outcome-simpleio"]},"moodle-core_outcome-dynamicpanel":{"requires":["base","moodle-core_outcome-simpleio","classnamemanager","moodle-core-notification-dialogue","moodle-core_outcome-scrollpanel"]},"moodle-core_outcome-ariacontrol":{"requires":["plugin","widget","escape"]},"moodle-core_outcome-ariacontrolled":{"requires":["plugin","widget"]},"moodle-availability_completion-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_date-form":{"requires":["base","node","event","io","moodle-core_availability-form"]},"moodle-availability_grade-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_group-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_grouping-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_profile-form":{"requires":["base","node","event","moodle-core_availability-form"]},"moodle-availability_releasecode-form":{"requires":["base","node","event","event-valuechange","moodle-core_availability-form"]},"moodle-mod_assign-history":{"requires":["node","transition"]},"moodle-mod_attendance-groupfilter":{"requires":["base","node"]},"moodle-mod_customcert-rearrange":{"requires":["dd-delegate","dd-drag"]},"moodle-mod_hsuforum-livelog":{"requires":["widget"]},"moodle-mod_hsuforum-article":{"requires":["base","node","event","router","core_rating","querystring","moodle-mod_hsuforum-io","moodle-mod_hsuforum-livelog"]},"moodle-mod_hsuforum-io":{"requires":["base","io-base","io-form","io-upload-iframe","json-parse"]},"moodle-mod_quiz-quizbase":{"requires":["base","node"]},"moodle-mod_quiz-autosave":{"requires":["base","node","event","event-valuechange","node-event-delegate","io-form"]},"moodle-mod_quiz-modform":{"requires":["base","node","event"]},"moodle-mod_quiz-toolboxes":{"requires":["base","node","event","event-key","io","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-slot","moodle-core-notification-ajaxexception"]},"moodle-mod_quiz-questionchooser":{"requires":["moodle-core-chooserdialogue","moodle-mod_quiz-util","querystring-parse"]},"moodle-mod_quiz-util":{"requires":["node","moodle-core-actionmenu"],"use":["moodle-mod_quiz-util-base"],"submodules":{"moodle-mod_quiz-util-base":{},"moodle-mod_quiz-util-slot":{"requires":["node","moodle-mod_quiz-util-base"]},"moodle-mod_quiz-util-page":{"requires":["node","moodle-mod_quiz-util-base"]}}},"moodle-mod_quiz-dragdrop":{"requires":["base","node","io","dom","dd","dd-scroll","moodle-core-dragdrop","moodle-core-notification","moodle-mod_quiz-quizbase","moodle-mod_quiz-util-base","moodle-mod_quiz-util-page","moodle-mod_quiz-util-slot","moodle-course-util"]},"moodle-message_airnotifier-toolboxes":{"requires":["base","node","io"]},"moodle-block_gapps-popup":{"requires":["base","event"]},"moodle-block_gapps-gmail":{"requires":["base","event","handlebars"]},"moodle-block_xp-notification":{"requires":["base","node","handlebars","button-plugin","moodle-core-notification-dialogue"]},"moodle-block_xp-filters":{"requires":["base","node","moodle-core-dragdrop","moodle-core-notification-confirm","moodle-block_xp-rulepicker"]},"moodle-block_xp-rulepicker":{"requires":["base","node","handlebars","moodle-core-notification-dialogue"]},"moodle-filter_glossary-autolinker":{"requires":["base","node","io-base","json-parse","event-delegate","overlay","moodle-core-event","moodle-core-notification-alert","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-editor_atto-editor":{"requires":["node","transition","io","overlay","escape","event","event-simulate","event-custom","node-event-html5","node-event-simulate","yui-throttle","moodle-core-notification-dialogue","moodle-editor_atto-rangy","handlebars","timers","querystring-stringify"]},"moodle-editor_atto-plugin":{"requires":["node","base","escape","event","event-outside","handlebars","event-custom","timers","moodle-editor_atto-menu"]},"moodle-editor_atto-menu":{"requires":["moodle-core-notification-dialogue","node","event","event-custom"]},"moodle-editor_atto-rangy":{"requires":[]},"moodle-report_eventlist-eventfilter":{"requires":["base","event","node","node-event-delegate","datatable","autocomplete","autocomplete-filters"]},"moodle-report_loglive-fetchlogs":{"requires":["base","event","node","io","node-event-delegate"]},"moodle-report_outcome-resetoptions":{"requires":["base","moodle-core_outcome-simpleio"]},"moodle-report_outcome-autocomplete":{"requires":["base","autocomplete","autocomplete-filters","autocomplete-highlighters"]},"moodle-gradereport_history-userselector":{"requires":["escape","event-delegate","event-key","handlebars","io-base","json-parse","moodle-core-notification-dialogue"]},"moodle-qbank_editquestion-chooser":{"requires":["moodle-core-chooserdialogue"]},"moodle-tool_lp-dragdrop-reorder":{"requires":["moodle-core-dragdrop"]},"moodle-assignfeedback_editpdf-editor":{"requires":["base","event","node","io","graphics","json","event-move","event-resize","transition","querystring-stringify-simple","moodle-core-notification-dialog","moodle-core-notification-alert","moodle-core-notification-warning","moodle-core-notification-exception","moodle-core-notification-ajaxexception"]},"moodle-atto_accessibilitychecker-button":{"requires":["color-base","moodle-editor_atto-plugin"]},"moodle-atto_accessibilityhelper-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_align-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_bold-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_bsgrid-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_charmap-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_chemistry-button":{"requires":["moodle-editor_atto-plugin","moodle-core-event","io","event-valuechange","tabview","array-extras"]},"moodle-atto_clear-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_collapse-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_count-button":{"requires":["io","json-parse","moodle-editor_atto-plugin"]},"moodle-atto_emojipicker-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_emoticon-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_equation-button":{"requires":["moodle-editor_atto-plugin","moodle-core-event","io","event-valuechange","tabview","array-extras"]},"moodle-atto_filedragdrop-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_fullscreen-button":{"requires":["event-resize","moodle-editor_atto-plugin"]},"moodle-atto_h5p-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_hr-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_html-beautify":{},"moodle-atto_html-button":{"requires":["promise","moodle-editor_atto-plugin","moodle-atto_html-beautify","moodle-atto_html-codemirror","event-valuechange"]},"moodle-atto_html-codemirror":{"requires":["moodle-atto_html-codemirror-skin"]},"moodle-atto_htmlplus-beautify":{},"moodle-atto_htmlplus-button":{"requires":["moodle-editor_atto-plugin","moodle-atto_htmlplus-beautify","moodle-atto_htmlplus-codemirror","event-valuechange"]},"moodle-atto_htmlplus-codemirror":{"requires":["moodle-atto_htmlplus-codemirror-skin"]},"moodle-atto_image-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_imagedragdrop-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_indent-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_italic-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_kalturamedia-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_link-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_managefiles-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_managefiles-usedfiles":{"requires":["node","escape"]},"moodle-atto_media-button":{"requires":["moodle-editor_atto-plugin","moodle-form-shortforms"]},"moodle-atto_noautolink-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_orderedlist-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_recordrtc-recording":{"requires":["moodle-atto_recordrtc-button"]},"moodle-atto_recordrtc-button":{"requires":["moodle-editor_atto-plugin","moodle-atto_recordrtc-recording"]},"moodle-atto_rtl-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_strike-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_subscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_superscript-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_table-button":{"requires":["moodle-editor_atto-plugin","moodle-editor_atto-menu","event","event-valuechange"]},"moodle-atto_title-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_underline-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_undo-button":{"requires":["moodle-editor_atto-plugin"]},"moodle-atto_unorderedlist-button":{"requires":["moodle-editor_atto-plugin"]}}},"gallery":{"name":"gallery","base":"https:\/\/portalead.espro.org.br\/lib\/yuilib\/gallery\/","combine":true,"comboBase":"https:\/\/portalead.espro.org.br\/theme\/yui_combo.php?","ext":false,"root":"gallery\/1723176132\/","patterns":{"gallery-":{"group":"gallery"}}}},"modules":{"core_filepicker":{"name":"core_filepicker","fullpath":"https:\/\/portalead.espro.org.br\/lib\/javascript.php\/1723176132\/repository\/filepicker.js","requires":["base","node","node-event-simulate","json","async-queue","io-base","io-upload-iframe","io-form","yui2-treeview","panel","cookie","datatable","datatable-sort","resize-plugin","dd-plugin","escape","moodle-core_filepicker","moodle-core-notification-dialogue"]},"core_comment":{"name":"core_comment","fullpath":"https:\/\/portalead.espro.org.br\/lib\/javascript.php\/1723176132\/comment\/comment.js","requires":["base","io-base","node","json","yui2-animation","overlay","escape"]}},"logInclude":[],"logExclude":[],"logLevel":null};
M.yui.loader = {modules: {}};

//]]>
</script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-JSYYC9WQWX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-JSYYC9WQWX');
</script>
<!--
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet"> 
-->
<link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.5.2/css/all.css">
<style>
#snap-header .badge-count-container .snap-message-count .icon.fa-regular.fa-comment.fa-fw {
    background-image: url('/pluginfile.php/1/tool_themeassets/assets/0/comment-regular.svg');
    background-repeat: no-repeat;
    color: transparent;
    background-size: 70%;
    height: auto;
}
</style>
<!-- request in ZD ticket 302018- LR-->

<meta name="robots" content="noindex" /><meta name="theme-color" content="#1A2B4C">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href='//fonts.googleapis.com/css?family=Roboto:500,100,400,300' rel='stylesheet' type='text/css'>

</head>

<body  id="page-login-index" class="format-site  path-login dir-ltr lang-en yui-skin-sam yui3-skin-sam portalead-espro-org-br pagelayout-login course-1 context-1 notloggedin theme device-type-default snap-resource-card theme-snap layout-login contains-snap-custom_menu-spacer">

<div>
    <a class="sr-only sr-only-focusable" href="#maincontent">Skip to main content</a>
</div><script src="https://portalead.espro.org.br/lib/javascript.php/1723176132/lib/polyfills/polyfill.js"></script>
<script src="https://portalead.espro.org.br/theme/yui_combo.php?rollup/3.18.1/yui-moodlesimple-min.js"></script><script src="https://portalead.espro.org.br/theme/jquery.php/core/jquery-3.7.1.min.js"></script>
<script src="https://portalead.espro.org.br/lib/javascript.php/1723176132/lib/javascript-static.js"></script>
<script>
//<![CDATA[
document.body.className += ' jsenabled';
//]]>
</script>


<script src="https://plugin.handtalk.me/web/latest/handtalk.min.js"></script>
<script>
  var ht = new HT({
    token: "abd0c302c1ad88af1aa2e8690ce89de8",    
   avatar: "MAYA"
  });
</script>
<script type="text/javascript">
    setTimeout(function() {
        $('input').attr('autocomplete', 'off');
    }, 2000);
</script>
<!-- colocar este código abaixo da tag <body> -->
<!-- vlibras source -->
<div vw class="enabled" style="display:none;" id="vlibras">
    <div vw-access-button class="active" id="vlibrasclick"></div>
    <div vw-plugin-wrapper>
        <div class="vw-plugin-top-wrapper"></div>
    </div>
</div>
<script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
<script>
    new window.VLibras.Widget('https://vlibras.gov.br/app');
</script>

<script>
    window.addEventListener("load", function () {
        document.body.addEventListener("INDmenuBuilt", function () {
            if (document.getElementById("btvlibras") == null) {
                var b = document.createElement('button');
                b.setAttribute("id", "btvlibras");
                b.setAttribute("data-indopt", "vlibrasreader");
                b.setAttribute("role", "checkbox");
                b.setAttribute("aria-labelledby", "vlibrasreader_label_1 vlibrasreader_label_2");
                b.setAttribute("tabindex", "0");
                b.setAttribute("aria-checked", "false");

                b.innerHTML ='<svg version="1.2" baseProfile="tiny" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="126.04px" height="122.666px" viewBox="0 0 126.04 122.666" xml:space="preserve"> <path d="M108.875,61.237c0.002-10.126-4.098-19.334-10.711-25.996c-1.361-1.374-3.58-1.383-4.951-0.021c-1.372,1.361-1.381,3.577-0.02,4.951v-0.002c5.371,5.421,8.681,12.847,8.681,21.068c0.003,0.016,0,0.074,0.003,0.17c-0.032,8.219-3.401,15.663-8.842,21.071c-1.372,1.361-1.379,3.577-0.018,4.949c0.686,0.688,1.585,1.034,2.484,1.034c0.893,0,1.784-0.339,2.467-1.018c6.695-6.646,10.873-15.881,10.906-26.063V61.237z M109.015,19.872c-1.364-1.372-3.579-1.381-4.952-0.019c-1.369,1.363-1.378,3.579-0.016,4.951v-0.002c9.273,9.353,14.992,22.19,14.992,36.389c0,0.049,0,0.134,0.002,0.253c-0.058,14.206-5.878,27.071-15.267,36.398c-1.372,1.362-1.381,3.58-0.017,4.952c0.684,0.689,1.584,1.034,2.484,1.034c0.891,0,1.781-0.338,2.465-1.016c10.648-10.569,17.273-25.227,17.332-41.405v-0.217C126.042,45.092,119.536,30.468,109.015,19.872z M81.307,0.362c-1.189-0.59-2.621-0.451-3.677,0.355L35.889,32.576H3.502c-0.924,0-1.824,0.372-2.476,1.025C0.375,34.253,0,35.153,0,36.075v50.516c0,0.922,0.375,1.822,1.026,2.476c0.651,0.651,1.554,1.024,2.476,1.024H35.89l41.74,31.858c0.622,0.474,1.372,0.717,2.128,0.717c0.527,0,1.059-0.119,1.549-0.361c1.189-0.59,1.947-1.81,1.947-3.136V3.5C83.254,2.17,82.497,0.949,81.307,0.362z M76.255,112.092L39.196,83.809c-0.606-0.464-1.36-0.718-2.122-0.718H7V39.575h30.074c0.762,0,1.516-0.255,2.122-0.717l37.059-28.286V112.092z"></path> </svg> <span id="vlibras_label_1" aria-hidden="true" class="INDmenuBtn-text">V Libras</span> <span id="vlibras_label_2" aria-hidden="true" class="INDmenuBtn-desc">Aciona o V Libras</span>';

                // click
                b.addEventListener("click", function () {
                    document.getElementById("vlibras").style.display = "block";
                    document.getElementById("vlibrasclick").click();
                });

                var menu = document.getElementById("INDmenuBtnzWrap");
                menu.append(b);
            }
        });
    });
</script>
<!-- end of vlibras source -->
<header id='mr-nav' class='clearfix moodle-has-zindex'>
<div id="snap-header">
<a id="snap-home" title="Portal de Aprendizagem" class="logo" href="https://portalead.espro.org.br"><span class="sr-only">Portal de Aprendizagem Homepage</span></a>
<div class="float-right js-only row">
    <span class="hidden-md-down"></span></div>
</div>
</header>

<!-- moodle js hooks -->
<div id="page"><div id="page-content">
<!--
////////////////////////// MAIN  ///////////////////////////////
-->
<main id="moodle-page" class="clearfix">
<div id="page-header" class="clearfix">
</div>

<section id="region-main">
<div role="main"><span id="maincontent"></span><div class="m-y-3 hidden-sm-down"></div>
<div class="row snap-login-row"  id="logins">
    <div class="snap-login snap-login-option snap-login-cell" id="base-login">
        <h1 class="text-center"><img class="d-block mx-auto" alt="Portal de Aprendizagem" src="https://portalead.espro.org.br/pluginfile.php/1/theme_snap/logo/1723176132/Logo%20Positivo_CMYK_2_C.png"></h1>
        <form action="https://portalead.espro.org.br/login/index.php" method="post" id="login" class="snap-custom-form">
            <hr id="login_hr_first" style="display: none;">
            <input type="hidden" name="logintoken" value="FLb9lqgueYcpul9LeGAakgLuTo6bdgkV">
            <input id="anchor" type="hidden" name="anchor" value="">
            <script>document.getElementById('anchor').value = location.hash;</script>
            <p class="snap-indication">* indicates a required field</p>
            <div class="floating-label">
                <input  type="text" name="username" id="username" autocomplete="username" required
                        class="form-control"
                        value=""
                        placeholder="Username or email*">
                <label for="username">
                        Username or email*
                </label>
            </div>
            <div class="floating-label">
                <input type="password" name="password" id="password" autocomplete="current-password" value="" required
                       class="form-control"
                       placeholder="Password*">
                <label for="password" class="sr-only">Password*</label>
            </div>
            <a class="small btn btn-link btn-block" href="https://portalead.espro.org.br/login/forgot_password.php">Forgotten your username or password?</a>
            <button type="submit" class="btn btn-primary btn-block" id="loginbtn">Log in</button>
        </form>


            <div class="snap-login snap-login-option snap-login-box" id="snap-signup">
                <hr>
                <h2>Is this your first time here?</h2>
                <p><a class="btn btn-primary btn-block" id="signupbtn" role="button" href="https://portalead.espro.org.br/login/signup.php">Create new account</a></p>
            </div>
    </div>
</div>

    <div class="js-only snap-login snap-login-option snap-login-box" id="snap-login-help">
        <div class="snap-login-instructions">
            <a class="btn btn-primary btn-block iconhelp" href="#" data-toggle="modal" data-target="#login-help-modal">
                Help with login <img class="icon " alt="Help with login" title="Help with login" src="https://portalead.espro.org.br/theme/image.php/snap/theme_snap/1723176132/help" />
            </a>
            <!-- Modal -->
            <div class="modal fade" id="login-help-modal" tabindex="-1" role="dialog" aria-labelledby="login-help-modal-title" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <h5 class="modal-title" id="login-help-modal-title">Help with login</h5>
                  </div>
                  <div class="modal-body summary">
                      <br>
                      For full access to this site, you first need to create an account.
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>

<span class="snap-log-in-more snap-log-in-loading-spinner"></span></div></section>
</main>
</div>
</div>
</div>
<!-- close moodle js hooks -->


<footer id="moodle-footer" role="contentinfo" class="clearfix">
<div id="snap-site-footer"><div id="snap-footer-content"><div class="container">
    <div class="row">
        <div class="col-12">
            <div class="top">
                <div class="wrap-logo">
                    <a href="https://www.espro.org.br/" class="logo">
                        <img width="244" height="62" loading="lazy" src="
https://portalead.espro.org.br/pluginfile.php/1/tool_themeassets/assets/0/logo-espro-branco.png" alt="Espro">
                    </a>
                </div>
                <div class="wrap-right">

                </div>
            </div>
        </div>
    </div>
    <div class="row middle">
        <div class="col-md-3">
            <h4>Espro</h4>
            <div class="menu-menu_principal-container">
                <ul id="menu-menu_principal-1" class="menu">
                    <li>
                        <a href="https://www.espro.org.br/sobre-nos/">Sobre Nós</a>
                    </li>
                    <li>
                        <a href="https://www.espro.org.br/jovem-espro/">Trabalhar Sou Jovem</a>
                    </li>
                    <li>
                        <a href="https://www.espro.org.br/empresas/">Contratar Sou Empresa</a>
                    </li>
                    <li>
                        <a href="https://www.espro.org.br/entidades/">Contratar Sou Entidade</a>
                    </li>
                    <li>
                        <a href="https://www.espro.org.br/quero-aprender/">Quero Aprender</a>
                    </li>
                    <li>
                        <a href="https://www.espro.org.br/quero-apoiar/">Quero Apoiar Quero Ajudar</a>
                    </li>
                    <li>
                        <a href="https://www.espro.org.br/noticias/">Notícias e Histórias</a>
                    </li>
                    <li>
                        <a href="https://www.espro.org.br/fale-conosco/">Fale com a Gente</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="col-md-3">
            <h4>Institucional</h4>
            <div class="menu-menu_institucional-container">
                <ul id="menu-menu_institucional" class="menu">
                    <li>
                        <a href="https://www.espro.org.br/esprolovers/">Esprolovers</a>
                    </li>
                    <li>
                        <a target="_blank" rel="noopener" href="https://trabalheconosco.vagas.com.br/espro">Trabalhe Conosco</a>
                    </li>
                    <li>
                        <a href="https://www.espro.org.br/termos-de-uso/">Termos de Uso</a>
                    </li>
                    <li>
                        <a href="https://www.espro.org.br/politica-de-privacidade/">Política de Privacidade</a>
                    </li>
                    <li>
                        <a href="https://www.espro.org.br/politica-de-cookies/">Política de Cookies</a>
                    </li>
                    <li>
                        <a target="_blank" rel="noopener" href="https://www.canalintegro.com.br/espro">Espro Ético</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="col-md-3">
            <address>
                <h4>FALE COM A GENTE</h4>
                <p><a href="tel:+551131380800" target="_blank" rel="noopener">11 3138-0080</a></p>
                <h4>CENTRAL DE EXPERIÊNCIAS</h4>
                <p><a href="tel:+551125041174" target="_blank" rel="noopener">11 2504-1174</a></p>
                <h4>ENDEREÇO</h4>
                <p>RUA DA CONSOLAÇÃO, 247<br>
                    CONSOLAÇÃO – SÃO PAULO</p>
            </address>

            <a class="btn btn-custom small white transparent" href="https://www.espro.org.br/fale-conosco/#informacoes" target="_self" title="Ver Outras Regiões">Ver Outras Regiões</a>
        </div>
        <div class="col-md-3">
            <h4>SELOS</h4>
            <div class="wrap-seal">
                <div class="inner">
                    <figure>
                        <img width="195" height="110" src="https://portalead.espro.org.br/pluginfile.php/1/tool_themeassets/assets/0/logo-org.png" alt="Empresas com Refugiados">
                    </figure>
                </div>
                <div class="inner">
                    <figure>
                        <img width="170" height="82" src="https://portalead.espro.org.br/pluginfile.php/1/tool_themeassets/assets/0/selo-rotary.png" alt="Selo Rotary">
                    </figure>
                </div>
                <div class="inner">
                    <figure>
                        <img width="168" height="66" src="https://portalead.espro.org.br/pluginfile.php/1/tool_themeassets/assets/0/selo3-d4s.png" alt="D4S">
                    </figure>
                </div>
                <div class="inner">
                    <figure>
                        <img width="100" height="98" src="https://portalead.espro.org.br/pluginfile.php/1/tool_themeassets/assets/0/selo-doar.png" alt="Doar">
                    </figure>
                </div>
                <div class="inner">
                    <figure>
                        <img width="111" height="110" src="
https://portalead.espro.org.br/pluginfile.php/1/tool_themeassets/assets/0/selo-fornec.png" alt="Selo Fornecedores">
                    </figure>
                </div>
            </div>
        </div>
    </div>
</div></div></div>
<div id="snap-custom-menu-footer"><br><nav class="navbar navbar-expand-lg navbar-light"><ul class="navbar-collapse clearfix snap-navbar-content"><li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" id="drop-down-66c0f717972af66c0f7178989b5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#" aria-controls="drop-down-menu-66c0f717972af66c0f7178989b5">
        Jovem
    </a>
    <div class="dropdown-menu" role="menu" id="drop-down-menu-66c0f717972af66c0f7178989b5" aria-labelledby="drop-down-66c0f717972af66c0f7178989b5">
                <a class="dropdown-item" role="menuitem" href="https://portalead.espro.org.br/mod/page/view.php?id=9701" > Dúvidas Frequentes</a>
    </div>
</li><li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" id="drop-down-66c0f7179730666c0f7178989b6" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#" aria-controls="drop-down-menu-66c0f7179730666c0f7178989b6">
        Suporte
    </a>
    <div class="dropdown-menu" role="menu" id="drop-down-menu-66c0f7179730666c0f7178989b6" aria-labelledby="drop-down-66c0f7179730666c0f7178989b6">
                <a class="dropdown-item" role="menuitem" href="https://portalead.espro.org.br/mod/page/view.php?id=822092" > Instrutor</a>
                <a class="dropdown-item" role="menuitem" href="https://portalead.espro.org.br/mod/page/view.php?id=823367" > Jovem Aprendiz</a>
                <a class="dropdown-item" role="menuitem" href="https://portalead.espro.org.br/mod/page/view.php?id=822096" > Consultar antigos fóruns de suporte</a>
    </div>
</li><li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" id="drop-down-66c0f7179736366c0f7178989b7" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#" aria-controls="drop-down-menu-66c0f7179736366c0f7178989b7">
        Instrutor
    </a>
    <div class="dropdown-menu" role="menu" id="drop-down-menu-66c0f7179736366c0f7178989b7" aria-labelledby="drop-down-66c0f7179736366c0f7178989b7">
                <a class="dropdown-item" role="menuitem" href="https://portalead.espro.org.br/mod/questionnaire/view.php?id=9706" > Cadastro de Jovens sem acesso Teams</a>
                <a class="dropdown-item" role="menuitem" href="https://portalead.espro.org.br/mod/questionnaire/view.php?id=161613" > Cadastro de Jovens sem acesso Open LMS</a>
                <a class="dropdown-item" role="menuitem" href="https://portalead.espro.org.br/mod/book/view.php?id=17362" > Tutoriais</a>
                <a class="dropdown-item" role="menuitem" href="https://portalead.espro.org.br/mod/page/view.php?id=9702" > Dúvidas Frequentes Espro</a>
    </div>
</li><li class="nav-item">
    <a class="nav-link" href="https://espro.myopenlms.net/login/forgot_password.php" >Não sei minha senha</a>
</li></nav></ul></div>
<div class="row">
    <div id="mrooms-footer" class="helplink col-sm-6">
        <small>
            Built with <a href="https://www.openlms.net/" target="_blank" rel="noopener">Open LMS</a>,
    a <a href="https://moodle.com/" target="_blank" rel="noopener">Moodle</a>-based product.<br>
    Copyright &#169; 2024 Open LMS, All Rights Reserved.        </small>
    </div>
    <div class="langmenu col-sm-6 text-right">
        <div class="langmenu d-inline-block">
    <form method="get" action="https://portalead.espro.org.br/login/index.php" class="form-inline" id="single_select_f66c0f7178989b8">
            <label for="single_select66c0f7178989b9">
                <span class="accesshide " >Language</span>
            </label>
        <select  id="single_select66c0f7178989b9" class="custom-select langmenu" name="lang"
                 >
                    <option  value="en" selected>English ‎(en)‎</option>
                    <option  value="en_us" >English (United States) ‎(en_us)‎</option>
                    <option  value="pt_br" >Português - Brasil ‎(pt_br)‎</option>
        </select>
        <noscript>
            <input type="submit" class="btn btn-secondary ml-1" value="Go">
        </noscript>
    </form>
</div>    </div>
</div>
<div id="goto-top-link">
        <a class="btn btn-light" role="button" href="javascript:void(0)" aria-label = "Go to top">
            <i class="icon fa fa-arrow-up fa-fw" title="Go to top" aria-label="Go to top"></i>
        </a>
    </div><div id="page-footer">
<br/>
<a class="mobilelink" href="https://www.openlms.net/open-lms-mobile-app/">Get the mobile app</a></div>
</footer>

<script>
    window.addEventListener("load", function () {
        setTimeout(function () {
            document.getElementById("id_username").value = ""
        }, 500)
    })
</script>

<!-- Accessibility Code for "espro.org.br" -->
<script>
window.interdeal = {
    "sitekey": "bebd7e4a7dab78430bdc6d846c6fe2a1",
    "Position": "left",
    "domains": {
        "js": "https://cdn.equalweb.com/",
        "acc": "https://access.equalweb.com/"
    },
    "Menulang": "PT",
    "btnStyle": {
        "vPosition": [
            "20%",
            "20%"
        ],
        "scale": [
            "0.6",
            "0.6"
        ],
        "color": {
            "main": "#0e5b92",
            "second": "#ffffff"
        },
        "icon": {
            "type": 1,
            "shape": "circle"
        }
    }
};
(function(doc, head, body){
    var coreCall             = doc.createElement('script');
    coreCall.src             = interdeal.domains.js + 'core/4.6.6/accessibility.js';
    coreCall.defer           = true;
    coreCall.integrity       = 'sha512-894GO3vsAUBQYBvHfBURsRetYHKdlZO5rUgeokPZ1KEdmjxYFVxWZma4MJDsN6/3PZNjAUSr8turrN4MKr7mnQ==';
    coreCall.crossOrigin     = 'anonymous';
    coreCall.setAttribute('data-cfasync', true );
    body? body.appendChild(coreCall) : head.appendChild(coreCall);
})(document, document.head, document.body);
</script>
<script>
//<![CDATA[
var require = {
    baseUrl : 'https://portalead.espro.org.br/lib/requirejs.php/1723176132/',
    // We only support AMD modules with an explicit define() statement.
    enforceDefine: true,
    skipDataMain: true,
    waitSeconds : 0,

    paths: {
        jquery: 'https://portalead.espro.org.br/lib/javascript.php/1723176132/lib/jquery/jquery-3.7.1.min',
        jqueryui: 'https://portalead.espro.org.br/lib/javascript.php/1723176132/lib/jquery/ui-1.13.2/jquery-ui.min',
        jqueryprivate: 'https://portalead.espro.org.br/lib/javascript.php/1723176132/lib/requirejs/jquery-private'
    },

    // Custom jquery config map.
    map: {
      // '*' means all modules will get 'jqueryprivate'
      // for their 'jquery' dependency.
      '*': { jquery: 'jqueryprivate' },
      // Stub module for 'process'. This is a workaround for a bug in MathJax (see MDL-60458).
      '*': { process: 'core/first' },

      // 'jquery-private' wants the real jQuery module
      // though. If this line was not here, there would
      // be an unresolvable cyclic dependency.
      jqueryprivate: { jquery: 'jquery' }
    }
};

//]]>
</script>
<script src="https://portalead.espro.org.br/lib/javascript.php/1723176132/lib/requirejs/require.min.js"></script>
<script>
//<![CDATA[
M.util.js_pending("core/first");
require(['core/first'], function() {
require(['core/prefetch'])
;
M.util.js_pending('filter_mathjaxloader/loader'); require(['filter_mathjaxloader/loader'], function(amd) {amd.configure({"mathjaxconfig":"\nMathJax.Hub.Config({\n    config: [\"Accessible.js\", \"Safe.js\"],\n    errorSettings: { message: [\"!\"] },\n    skipStartupTypeset: true,\n    messageStyle: \"none\"\n});\n","lang":"en"}); M.util.js_complete('filter_mathjaxloader/loader');});;
require(["media_videojs/loader"], function(loader) {
    loader.setUp('en');
});;
require(['theme_boost/loader']);;
M.util.js_pending('theme_snap/snap'); require(['theme_snap/snap'], function(amd) {amd.snapInit({"id":"1","shortname":"\u00a0","contextid":1,"categoryid":false,"ajaxurl":"\/course\/rest.php","unavailablesections":[],"unavailablemods":[],"enablecompletion":false,"format":"site","partialrender":true,"toctype":"list"}, false, 524288000, false, false, 0, false, false, {"primary":"#82009e !default;","success":"#3d5c1f;","warning":"#b55600;","danger":"#990f3d;","info":"#02567e;"}, {"gradepercentage":2,"gradepercentagereal":21,"gradepercentageletter":23,"gradereal":1,"graderealpercentage":12,"graderealletter":13}); M.util.js_complete('theme_snap/snap');});;
M.util.js_pending('theme_snap/login_render-lazy'); require(['theme_snap/login_render-lazy'], function(amd) {amd.loginRender("1", null); M.util.js_complete('theme_snap/login_render-lazy');});;
M.util.js_pending('report_allylti/main'); require(['report_allylti/main'], function(amd) {amd.init(); M.util.js_complete('report_allylti/main');});;
M.util.js_pending('filter_oembed/oembed'); require(['filter_oembed/oembed'], function(amd) {amd.init(); M.util.js_complete('filter_oembed/oembed');});;

require(['jquery', 'core/custom_interaction_events'], function($, CustomEvents) {
    CustomEvents.define('#single_select66c0f7178989b9', [CustomEvents.events.accessibleChange]);
    $('#single_select66c0f7178989b9').on(CustomEvents.events.accessibleChange, function() {
        var ignore = $(this).find(':selected').attr('data-ignore');
        if (typeof ignore === typeof undefined) {
            $('#single_select_f66c0f7178989b8').submit();
        }
    });
});
;

    require(['jquery', 'core/yui'], function($, Y) {
    });
;
M.util.js_pending('theme_snap/wcloader'); require(['theme_snap/wcloader'], function(amd) {amd.init("{\"theme_snap\\\/snapce\":[\"https:\\\/\\\/portalead.espro.org.br\\\/pluginfile.php\\\/1\\\/theme_snap\\\/vendorjs\\\/snap-custom-elements\\\/snap-ce\"]}"); M.util.js_complete('theme_snap/wcloader');});;
M.util.js_pending('core/notification'); require(['core/notification'], function(amd) {amd.init(1, []); M.util.js_complete('core/notification');});;
M.util.js_pending('core/log'); require(['core/log'], function(amd) {amd.setConfig({"level":"warn"}); M.util.js_complete('core/log');});;
M.util.js_pending('core/page_global'); require(['core/page_global'], function(amd) {amd.init(); M.util.js_complete('core/page_global');});;
M.util.js_pending('core/utility'); require(['core/utility'], function(amd) {M.util.js_complete('core/utility');});
    M.util.js_complete("core/first");
});
//]]>
</script>
<script src="https://cdn.jsdelivr.net/npm/mathjax@2.7.9/MathJax.js?delayStartupUntil=configured"></script>
<script>
//<![CDATA[
M.str = {"moodle":{"lastmodified":"Last modified","name":"Name","error":"Error","info":"Information","yes":"Yes","no":"No","ok":"OK","cancel":"Cancel","unknownerror":"Unknown error","closebuttontitle":"Close","modhide":"Hide","modshow":"Show","hiddenoncoursepage":"Available but not shown on course page","showoncoursepage":"Show on course page","switchrolereturn":"Return to my normal role","show":"Show","hide":"Hide","groupsseparate":"Separate groups","groupsvisible":"Visible groups","groupsnone":"No groups","confirm":"Confirm","areyousure":"Are you sure?","file":"File","url":"URL","collapseall":"Collapse all","expandall":"Expand all"},"repository":{"type":"Type","size":"Size","invalidjson":"Invalid JSON string","nofilesattached":"No files attached","filepicker":"File picker","logout":"Logout","nofilesavailable":"No files available","norepositoriesavailable":"Sorry, none of your current repositories can return files in the required format.","fileexistsdialogheader":"File exists","fileexistsdialog_editor":"A file with that name has already been attached to the text you are editing.","fileexistsdialog_filemanager":"A file with that name has already been attached","renameto":"Rename to \"{$a}\"","referencesexist":"There are {$a} links to this file","select":"Select"},"admin":{"confirmdeletecomments":"Are you sure you want to delete the selected comment(s)?","confirmation":"Confirmation"},"theme_snap":{"coursecontacts":"Course Contacts","debugerrors":"Debug Errors","problemsfound":"Problems Found","error:coverimageexceedsmaxbytes":"Cover image exceeds the site level maximum allowed file size ({$a})","error:coverimageresolutionlow":"For best quality, we recommend a larger image of at least 1024px width.","forumtopic":"Topic","forumauthor":"Author","forumpicturegroup":"Group","forumreplies":"Replies","forumlastpost":"Last Post","hiddencoursestoggle":"Hidden courses","loading":"Loading...","more":"More","moving":"Moving \"{$a}\"","movingcount":"Moving {$a} objects","movehere":"Move here","movefailed":"Move failed for \"{$a}\"","movingdropsectionhelp":"Place section \"{$a->moving}\" before section \"{$a->before}\"","movingstartedhelp":"Navigate to where you would like to place section \"{$a}\"","notpublished":"Not published to students","visibility":"Visibility","snapfeedsblocktitle":"Snap feeds","imageproperties":"Image properties","coverimagedesc":"Select the image to feature on the cover, ensuring it is in either .jpeg, .png, or .gif format. It should not exceed the site level maximum allowed file size ({$a}). For optimal display, aim for an aspect ratio of 4:3 (1024x768 pixels). Additionally, consider color combinations that adhere to WCAG 2.0 guidelines, especially in relation to the white title of the course, for an enhanced user experience.","coverimagecropperdesc":"Using the crop box, select the area of the image that will be displayed.","browserepositories":"Upload a new image","selectimage":"Select image","deleteimage":"Delete cover image","confirmdeletefile":"This action will delete the cover image. Are you sure you want to delete the saved file?","coverimagesettingswarning":"If you update the cover image directly from the course settings page, the cropped cover image will reset. Please remember to reselect the desired crop afterward."},"booktool_print":{"printbook":"Print book"},"completion":{"progresstotal":"Progress: {$a->complete} \/ {$a->total}"},"debug":{"debuginfo":"Debug info","line":"Line","stacktrace":"Stack trace"},"langconfig":{"labelsep":": "}};
//]]>
</script>
<script>
//<![CDATA[
(function() {M.util.help_popups.setup(Y);
 M.util.js_pending('random66c0f7178989b13'); Y.on('domready', function() { M.util.js_complete("init");  M.util.js_complete('random66c0f7178989b13'); });
})();
//]]>
</script>
<!-- bye! -->


</body></html>